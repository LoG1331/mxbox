# email_worker

The current stack has 2 parts:

- `server`: Express + SQLite backend
- `frontend`: Vite React frontend

The edge forwarder (Cloudflare Email Worker that receives mail and forwards it to the server) is documented in [docs/FORWARDER.md](docs/FORWARDER.md).

## Quick start

### Install from npm (simplest)

```bash
npm install -g @log1331/mxbox   # or: npx @log1331/mxbox
mxbox                           # open http://localhost:3001
```

The first run creates `~/.local/mxbox/` (DB + `.env` with random secrets) and prints the admin password exactly once. Options: `mxbox --port 8080 --host 0.0.0.0`. The data dir can be changed via the `MXBOX_HOME` environment variable.

### From source

From the repo root:

```bash
npm run dev
```

This command runs both:

- backend at `http://127.0.0.1:3001`
- frontend at `http://127.0.0.1:3002`

## Run each part separately

```bash
npm run server:dev
npm run frontend:dev
```

## Production

Build the frontend once, then run the backend:

```bash
npm run build
npm run start
```

After the build, `server` also serves the files in `frontend/dist` on the same origin.

To generate a production `.env` with bootstrap secrets:

```bash
npm run env:init
```

This command creates or updates `.env` at the repo root. `npm run start` automatically sources this file if it exists.

## Default local dev login

- `username`: `admin`
- `password`: `admin-pass-123`

## Main scripts

```bash
npm run build
npm run env:init
npm run start
npm run server:start
npm run frontend:build
npm run frontend:lint
npm run server:test
npm run server:openapi
```

## Default dev env

The root scripts set local defaults automatically:

- `PORT=3001`
- `NEW_SERVER_SQLITE_PATH=./data/new-server-dev.sqlite`
- `INBOUND_AUTH_TOKEN=dev-inbound-token`
- `BOOTSTRAP_ADMIN_USERNAME=admin`
- `BOOTSTRAP_ADMIN_PASSWORD=admin-pass-123`
- `CORS_ALLOWED_ORIGINS=http://127.0.0.1:3002`

You can override them with env vars before running a script.

Note: `BOOTSTRAP_ADMIN_*` in the dev scripts is only for local bootstrap. The backend no longer overwrites the password/profile of an existing user on restart.

## Telegram Bot

The backend supports a Telegram bot in webhook mode. The bot's main configuration is now stored via the frontend admin; no separate Telegram env vars are needed for token/webhook anymore.

The bot maps users via `users.telegram_id` and uses the existing permission/mailbox registration.
